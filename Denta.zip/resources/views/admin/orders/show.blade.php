<x-admin-layout>
    @livewire('status-order', ['order' => $order])
    
</x-admin-layout>