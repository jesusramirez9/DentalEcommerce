<div>
    <div class=" w-full top-0 hidden lg:block">
        <div class="lg:px-10 xl:px-30 flex items-center h-12 justify-between text-xs xl:text-sm">
            <div>
                <p> <img src="<?php echo e(asset('dental/home/hora.png')); ?>" class="inline-block" alt="">  Horario de trabajo <span class="font-medium">Lun - Vie 8:00 - 18:00</span> </p>
            </div>
            <div>
                
                <p> <img src="<?php echo e(asset('dental/home/telefono.png')); ?>" class="inline-block" alt=""> Teléfono <span class="font-medium">0800 2546 781</span> </p>
            </div>
            <div>
                
                <p> <img src="<?php echo e(asset('dental/home/ubi.png')); ?>" class="inline-block" alt=""> Visítanos en <span class="font-medium">Av. Pardo 180 Miraflores</span> </p>
            </div>
          
            <div class="flex items-center">
                <a href="" class="md:mx-6"><img  src="<?php echo e(asset('dental/home/facebook.png')); ?>"
                        alt=""></a>
                <a href="" class=""><img  src="<?php echo e(asset('dental/home/instagram.png')); ?>">
            </div>
        </div>
    </div>
     <header class="md:border-t md:border-gray-400 md:border-opacity-40 w-full py-4 top-0" style="z-index: 900" x-data="dropdown()">
        <div class="container flex items-center h-16 justify-between md:justify-center">
            <a :class="{'bg-opacity-100 text-orange-500' : open}" x-on:click="show()"
                class="flex flex-col items-center justify-center md:hidden order-last md:order-first px-2 md:px-4 bg-gray-500 bg-opacity-25 text-white cursor-pointer font-semibold h-2/3">
                <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                    <path class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4 6h16M4 12h16M4 18h16" />
                </svg>

                
            </a>
            <a href="/">
                <img src="<?php echo e(asset('dental/home/logo.png')); ?>" class="hidden lg:block" alt="">
            </a>
            
            <div class="relative  hidden md:block" >
                <a  href="/"
                    class="flex flex-row items-center w-full px-4 py-2 mt-2 text-xs xl:text-sm font-semibold text-left bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:focus:bg-gray-600 dark-mode:hover:bg-gray-600 md:w-auto md:inline md:mt-0 md:ml-4 xl:ml-24 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline <?php echo e(request()->is('/') ? 'active  border-purple-700  bg-purple-600 bg-opacity-20' : ''); ?>">
                    <span>Inicio</span>
                </a>   
            </div>
           
            <div class="relative hidden lg:block" >
                <a href="<?php echo e(route('conocenos')); ?>"
                    class="flex flex-row items-center w-full px-4 py-2 mt-2 text-xs xl:text-sm font-semibold text-left bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:focus:bg-gray-600 dark-mode:hover:bg-gray-600 md:w-auto md:inline md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline <?php echo e(request()->is('conocenos') ? 'active  border-purple-700  bg-purple-600 bg-opacity-20' : ''); ?>">
                    <span>Nosotros</span>
                </a>   
            </div>
            <div  class="relative hidden md:block" >
                <a href="<?php echo e(route('especialidad')); ?>"
                    class="flex flex-row items-center w-full px-2 py-2 mt-2 text-xs  xl:text-sm font-semibold text-left bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:focus:bg-gray-600 dark-mode:hover:bg-gray-600 md:w-auto md:inline md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline <?php echo e(request()->is('especialidad') ? 'active  border-purple-700  bg-purple-600 bg-opacity-20' : ''); ?>">
                    <span>Especialidades</span>
                 
                </a>
         
            </div>

            <div  class="relative hidden md:block">
                <a href="<?php echo e(route('tratamiento')); ?>"
                    class="flex flex-row items-center w-full px-2 py-2 mt-2 text-xs xl:text-sm font-semibold text-left bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:focus:bg-gray-600 dark-mode:hover:bg-gray-600 md:w-auto md:inline md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline <?php echo e(request()->is('tratamiento') ? 'active  border-purple-700  bg-purple-600 bg-opacity-20' : ''); ?>">
                    <span>Tratamientos</span>                   
                </a>
            </div>

            <div  class="relative hidden md:block">
                <a href="/categories/dental"
                    class="flex flex-row items-center w-full px-2 py-2 mt-2 text-xs xl:text-sm font-semibold text-left bg-transparent rounded-lg dark-mode:bg-transparent dark-mode:focus:text-white dark-mode:hover:text-white dark-mode:focus:bg-gray-600 dark-mode:hover:bg-gray-600 md:w-auto md:inline md:mt-0 md:ml-4 hover:text-gray-900 focus:text-gray-900 hover:bg-gray-200 focus:bg-gray-200 focus:outline-none focus:shadow-outline <?php echo e(request()->is('categories*','products*','orders*','shopping-cart*') ? 'active  border-purple-700  bg-purple-600 bg-opacity-20' : ''); ?>">
                    <span>Productos</span>                   
                </a>
            </div>

            <a href="<?php echo e(route('contacto')); ?>"
                class=" xl:mx-6 text-white text-xs xl:text-sm bg-green-500 px-2 py-1 xl:px-6 rounded-md hidden md:block  <?php echo e(request()->is('contactanos') ? 'active linktran  bg-green-500 px-4 py-0.5 rounded-xl ' : ''); ?>">
                Reservar Cita
            </a>

            <div class="mx-4  relative hidden md:block">
                <?php if(auth()->guard()->check()): ?>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown','data' => ['align' => 'right','width' => '48']]); ?>
<?php $component->withName('jet-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                         <?php $__env->slot('trigger'); ?> 

                            <button
                                class="flex text-xs xl:text-sm border-2 border-transparent rounded-full focus:outline-none focus:border-gray-300 transition">
                                <img class="h-8 w-8 rounded-full object-cover"
                                    src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
                            </button>

                         <?php $__env->endSlot(); ?>

                         <?php $__env->slot('content'); ?> 
                            <!-- Account Management -->
                            <div class="block px-4 py-2 text-xs text-gray-400">
                                <?php echo e(__('Manage Account')); ?>

                            </div>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('profile.show')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('profile.show')).'']); ?>
                                <?php echo e(__('Profile')); ?>

                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('orders.index')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('orders.index')).'']); ?>
                                Mis ordenes
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('admin.index')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.index')).'']); ?>
                                    Administrador
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php endif; ?>

                            <div class="border-t border-gray-100"></div>

                            <!-- Authentication -->
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                                        this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                                        this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Log Out')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                         <?php $__env->endSlot(); ?>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php else: ?>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown','data' => ['align' => 'right','width' => '48']]); ?>
<?php $component->withName('jet-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>

                         <?php $__env->slot('trigger'); ?> 
                            <i class="fas fa-user-circle text-gray-700 text-3xl cursor-pointer"></i>
                         <?php $__env->endSlot(); ?>

                         <?php $__env->slot('content'); ?> 
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('login')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('login')).'']); ?>
                                <?php echo e(__('Login')); ?>

                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('register')).'']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('register')).'']); ?>
                                <?php echo e(__('Register')); ?>

                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                         <?php $__env->endSlot(); ?>

                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php endif; ?>
            </div>

            <div class="hidden md:block">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dropdown-cart')->html();
} elseif ($_instance->childHasBeenRendered('FOoHKiI')) {
    $componentId = $_instance->getRenderedChildComponentId('FOoHKiI');
    $componentTag = $_instance->getRenderedChildComponentTagName('FOoHKiI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FOoHKiI');
} else {
    $response = \Livewire\Livewire::mount('dropdown-cart');
    $html = $response->html();
    $_instance->logRenderedChild('FOoHKiI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
      


        </div>

        <nav id="navigation-menu" :class="{'block': open, 'hidden': !open}"
            class="bg-trueGray-700 mt-4 z-10 bg-opacity-25 w-full absolute hidden">

            
            

            
            <div class="bg-white h-2/5 overflow-y-auto">

                <div class="container bg-gray-200 py-3 mb-2">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('g3Icpvi')) {
    $componentId = $_instance->getRenderedChildComponentId('g3Icpvi');
    $componentTag = $_instance->getRenderedChildComponentTagName('g3Icpvi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('g3Icpvi');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('g3Icpvi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

                <ul>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <li>
                        <a href="/"
                            class="py-2 px-4 text-xs xl:text-sm flex items-center <?php echo e(request()->is('/') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <i class="fas fa-tooth"></i>
                            </span>
                            Inicio
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('conocenos')); ?>"
                            class="py-2 px-4 text-xs xl:text-sm flex items-center <?php echo e(request()->is('conocenos') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <i class="fas fa-tooth"></i>
                            </span>
                            Nosotros
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('especialidad')); ?>}}"
                            class="py-2 px-4 text-xs xl:text-sm flex items-center <?php echo e(request()->is('especialidad') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <i class="fas fa-tooth"></i>
                            </span>
                            Especialidades
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('tratamiento')); ?>"
                            class="py-2 px-4 text-xs xl:text-sm flex items-center <?php echo e(request()->is('tratamiento') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <i class="fas fa-tooth"></i>
                            </span>
                            Tratamientos
                        </a>
                    </li>
                    <li>
                        <a href="/categories/dental"
                            class="py-2 px-4 text-xs xl:text-sm flex items-center <?php echo e(request()->is('categories/*','products*','orders*','shopping-cart*') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <i class="fas fa-tooth"></i>
                            </span>
                            Productos
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contacto')); ?>" class="py-2 px-4 text-xs xl:text-sm flex items-center <?php echo e(request()->is('contacto') ? 'active text-yellow-500 underline' : ''); ?>">
                            <span class="flex justify-center w-9">
                                <i class="fas fa-tooth"></i>
                            </span>
                            Contáctenos
                        </a>
                    </li>

                </ul>
                
            </div>
        </nav>
    </header>
    
    <?php $__env->startPush('script'); ?>
        <script type="text/javascript">
          
            window.addEventListener("scroll", function(){
			var header = document.querySelector("header");
			header.classList.toggle("abajo",window.scrollY>0);
		})
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Dental Ecommerce\resources\views/livewire/navigation.blade.php ENDPATH**/ ?>