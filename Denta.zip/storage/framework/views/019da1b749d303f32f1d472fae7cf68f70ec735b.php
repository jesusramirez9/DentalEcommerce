<?php $attributes = $attributes->exceptProps(['size' => 35, 'color' => 'gray']); ?>
<?php foreach (array_filter((['size' => 35, 'color' => 'gray']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    switch ($color) {
        case 'gray':
           
            $col = "#374151";

            break;
        case 'white':
        $col = "#FFFFFF";
            break;
        default:
        $col = "gray";
            break;
    }    
?>



<i class="fas fa-cart-plus fa-2x"></i><?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Dental Ecommerce\resources\views/components/cart.blade.php ENDPATH**/ ?>