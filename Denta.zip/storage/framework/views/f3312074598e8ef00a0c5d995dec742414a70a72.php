<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container  py-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-24">
            <div>
                <!-- Place somewhere in the <body> of your page -->
                <div class="md:mt-0 mb-3">
                    <p class="titl_cata"> Producto / <span class="tipo_catalog"><?php echo e($product->name); ?></span> </p>
                </div>


                <div class="flexslider">
                    <ul class="slides">

                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li class="" data-thumb="<?php echo e(Storage::url($image->url)); ?>">
                                <img class="" src="<?php echo e(Storage::url($image->url)); ?>" />
                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                </div>

                
            </div>
            <div class="-mt-8 md:mt-12">
                <h1 class="text-xl font-bold  title_product"><?php echo e($product->name); ?></h1>
           
                <p class="text-2xl my-4 font-semibold ">S/ <?php echo e($product->price); ?></p>
                <hr class=" mb-4 hrgreen">
                <div class="bg-white rounded-lg shadow-lg mb-6 ">
                    <div class="flex p-4 items-center">
                        <span class="flex items-center justify-center h-10 w-10 rounded-full bg-greenLime-600">
                            <i class="fas fa-truck text-sm text-white"></i>
                        </span>
                        <div class="ml-4">
                          
                            <p>Recógelo el <?php echo e(Date::now()->addDay(1)->locale('es')->format('l j F')); ?> en nuestro local principal</p>
                        </div>
                    </div>
                </div>

                <?php if($product->subcategory->size): ?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item-size', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('KiYoGds')) {
    $componentId = $_instance->getRenderedChildComponentId('KiYoGds');
    $componentTag = $_instance->getRenderedChildComponentTagName('KiYoGds');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KiYoGds');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item-size', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('KiYoGds', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php elseif($product->subcategory->color): ?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item-color', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('KkwBRyU')) {
    $componentId = $_instance->getRenderedChildComponentId('KkwBRyU');
    $componentTag = $_instance->getRenderedChildComponentTagName('KkwBRyU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KkwBRyU');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item-color', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('KkwBRyU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php else: ?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-cart-item', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('7wiwPy3')) {
    $componentId = $_instance->getRenderedChildComponentId('7wiwPy3');
    $componentTag = $_instance->getRenderedChildComponentTagName('7wiwPy3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7wiwPy3');
} else {
    $response = \Livewire\Livewire::mount('add-cart-item', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('7wiwPy3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php endif; ?>

                <div class="bg-detalledeliv mt-4">
                    <div class="flex">
                        <div>
                            <img src="<?php echo e(asset('images/catalogoproductos/checkm.png')); ?>" alt="">
                        </div>
                        <div class="ml-3">
                            <h1 class="detalledeliv">Compra satisfactoria</h1>
                            
                        </div>
                    </div>
                    <div class="flex mt-4">
                        <div>
                            <img src="<?php echo e(asset('images/catalogoproductos/fast.png')); ?>" alt="">
                        </div>
                        <div class="ml-3">
                            <h1 class="detalledeliv">Delivery a todo lima</h1>
                        </div>
                    </div>
                    <div class="flex mt-4">
                        <div>
                            <img src="<?php echo e(asset('images/catalogoproductos/cards.png')); ?>" alt="">
                        </div>
                        <div class="ml-3">
                            <h1 class="detalledeliv">Paga en línea de manera segura</h1>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="">
            <div class="mt-0 md:mt-8">
                <div class="mytabs">
                    <input type="radio" name="mytabs" id="tabfree" checked="checked">
                    <label for="tabfree" class=" underlinetxt ">Descripción</label>
                    <div class="tab">

                        <p><?php echo $product->description; ?></p>
                    </div>

                    <input type="radio" name="mytabs" id="tabsilver">
                    <label for="tabsilver" class=" underlinetxt ">Especificaciones</label>
                    <div class="tab">

                        <p><?php echo $product->specification; ?></p>
                    </div>
                </div>
            </div>
        </div>
     
        <div class="text-center">
            <div class="text-center py-4 md:py-8 ">
                <p class="text-xl md:text-2xl lg:text-4xl text-purple-700 font-black">Más Productos </p>
            </div>
           
            <div class="glider-contain">

                <div class="prelacionado">
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $subcategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                            <div class="mx-4">
                                <a href="<?php echo e(route('products.show', $product)); ?>">
                                <figure>
                                        
                                    <?php if($product->images->count()): ?>
                                        <img class="h-80 w-full object-cover object-center scrollflow -slide-bottom -opacity"
                                            src="<?php echo e(Storage::url($product->images->first()->url)); ?>" alt="">
                                    <?php else: ?>
                                        <img class="h-80 w-full object-cover object-center"
                                            src="https://images.pexels.com/photos/5082560/pexels-photo-5082560.jpeg?cs=srgb&dl=pexels-cottonbro-5082560.jpg&fm=jpg"
                                            alt="">
                                    <?php endif; ?>

                                </figure>
                                <p class="titl_product lg:text-left"><?php echo e($product->name); ?></p>
                                <p class="price_prodc lg:text-left"><?php echo e($product->price); ?></p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button aria-label="Previous" class="glider-prev glid-img1"></button>
                <button aria-label="Next" class="glider-next glid-img2"></button>

            </div>

        </div>



    </div>
    <?php $__env->startPush('script'); ?>
        <script>
            // Can also be used with $(document).ready()
            $(document).ready(function() {
                $('.flexslider').flexslider({
                    animation: "slide",
                    controlNav: "thumbnails"
                });
            });

            new Glider(document.querySelector('.prelacionado'), {
                slidesToShow: 3,
                slidesToScroll: 1,
                draggable: true,
                dots: '.dots',
                arrows: {
                    prev: '.glider-prev',
                    next: '.glider-next'
                },
                responsive: [{
                        // screens greater than >= 775px
                        breakpoint: 768,
                        settings: {
                            // Set to `auto` and provide item width to adjust to viewport
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            itemWidth: 150,
                            duration: 1.5
                        }
                    },

                    {
                        // screens greater than >= 1024px
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1,
                            itemWidth: 150,
                            duration: 1.5,
                            arrows: {
                                prev: '.glider-prev',
                                next: '.glider-next'
                            },

                        }
                    },
                    {
                        // screens greater than >= 1024px
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            itemWidth: 150,
                            duration: 0.25,
                            arrows: false
                        }
                    },
                    {
                        // screens greater than >= 1024px
                        breakpoint: 320,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            itemWidth: 150,
                            duration: 0.25,
                            arrows: false
                        }
                    }

                ]
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Dental Ecommerce\resources\views/products/show.blade.php ENDPATH**/ ?>