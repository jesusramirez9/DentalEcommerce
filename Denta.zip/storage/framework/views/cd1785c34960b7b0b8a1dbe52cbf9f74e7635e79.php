<div x-data>
    <div class="text-xl text-gray-700">
        <p class="sizecol mb-4">Elige tu talla: </p>
        <div wire:model="size_id" class="divsize">
            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="btn-group" role="group">
                    <input type="radio" class="btn-check" value="<?php echo e($size->id); ?>" name="size"
                        id="<?php echo e($size->name); ?>" autocomplete="off">
                    <label class="btn btn-outline-primary mr-3 btn_talla"
                        for="<?php echo e($size->name); ?>"><?php echo e($size->name); ?></label>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>



    </div>

    <div class="text-xl text-gray-700 mt-4">
        <p class="sizecol mt-8 mb-4">Elige tu color:</p>

        <div wire:model="color_id" class="divsize">
            

            <?php $__empty_1 = true; $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="btn-group" role="group">
                    <input type="radio" class="btn-check" value="<?php echo e($color->id); ?>" name="color"
                        id="<?php echo e(__($color->name)); ?>" autocomplete="off">
                    <label class="btn btn-outline-primary mr-3 btn_talla btn_color" for="<?php echo e(__($color->name)); ?>"
                        style="background-color: <?php echo e($color->name); ?>"></label>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm">Elige una talla para elegir un color</p>

            <?php endif; ?>

            
        </div>

        

    </div>
    <hr class="mt-8 mb-4 hrgreen">
    <p class="text-gray-700 my-4"> <span class="text-lg font-semibold">Stock disponible: </span>
        <?php if($quantity): ?>
            <?php echo e($quantity); ?>

        <?php else: ?>
            <?php echo e($product->stock); ?>

        <?php endif; ?>
    </p>

    <div class="flex ">
        <div class="mr-4 bordradiu">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['class' => 'btn_menmas','disabled' => true,'xBind:disabled' => '$wire.qty <= 1','wire:loading.attr' => 'disabled','wire:target' => 'decrement','wire:click' => 'decrement']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn_menmas','disabled' => true,'x-bind:disabled' => '$wire.qty <= 1','wire:loading.attr' => 'disabled','wire:target' => 'decrement','wire:click' => 'decrement']); ?>
                -
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <span class="mx-2 text-gray-700 qtydad"><?php echo e($qty); ?></span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['class' => 'btn_menmas','xBind:disabled' => '$wire.qty >= $wire.quantity','wire:loading.attr' => 'disabled','wire:target' => 'increment','wire:click' => 'increment']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn_menmas','x-bind:disabled' => '$wire.qty >= $wire.quantity','wire:loading.attr' => 'disabled','wire:target' => 'increment','wire:click' => 'increment']); ?>
                +
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="flex-1">

            <div class="itemcolbtnweb">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['xBind:disabled' => '$wire.qty > $wire.quantity','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem','color' => 'orange','class' => 'w-full agregar']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-bind:disabled' => '$wire.qty > $wire.quantity','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem','color' => 'orange','class' => 'w-full agregar']); ?>
                    Agregar a la bolsa
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
            <div class="itemcolorbtn">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['xBind:disabled' => '$wire.qty > $wire.quantity','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem','color' => 'orange','class' => 'w-full']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-bind:disabled' => '$wire.qty > $wire.quantity','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem','color' => 'orange','class' => 'w-full']); ?>
                    Agregar
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        



            
        </div>
    </div>

 
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Dental Ecommerce\resources\views/livewire/add-cart-item-size.blade.php ENDPATH**/ ?>