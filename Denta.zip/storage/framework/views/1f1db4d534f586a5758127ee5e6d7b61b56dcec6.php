<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <div class="relative h-contacto bg-center bg-cover w-full object-cover object-center"
            style="background-image: url('<?php echo e(asset('dental/nosotros/producto.jpg')); ?>')">
            <div class="absolute bg-black bg-opacity-30 w-full h-full">

            </div>
            <div
                class="mt-8 absolute text-center max-w-full mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-36 text-white font-bold text-2xl lg:text-4xl lr">
                <p class="m-0 shdot-text text-2xl">Tu mejor experiencia dental con nuestros productos</p>
                <p class="m-0 shdot-text font-black text-2xl lg:text-6xl xl:text-8xl">Dentales</p>
                
            </div>
        </div>
    </div>
    <div class="container  pt-6 md:pt-14 pb-14">
        

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category-filter', ['category' => $category])->html();
} elseif ($_instance->childHasBeenRendered('BQiAAvv')) {
    $componentId = $_instance->getRenderedChildComponentId('BQiAAvv');
    $componentTag = $_instance->getRenderedChildComponentTagName('BQiAAvv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BQiAAvv');
} else {
    $response = \Livewire\Livewire::mount('category-filter', ['category' => $category]);
    $html = $response->html();
    $_instance->logRenderedChild('BQiAAvv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Dental Ecommerce\resources\views/categories/show.blade.php ENDPATH**/ ?>