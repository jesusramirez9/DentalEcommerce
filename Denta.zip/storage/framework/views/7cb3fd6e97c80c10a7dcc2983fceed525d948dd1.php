<div x-data>


    <p class="text-gray-700 mb-4"> <span class="text-lg font-semibold">Stock disponible: </span><?php echo e($quantity); ?></p>
    <div class="flex">
        <div class="mr-4 bordradiu">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['class' => 'btn_menmas','disabled' => true,'xBind:disabled' => '$wire.qty <= 1','wire:loading.attr' => 'disabled','wire:target' => 'decrement','wire:click' => 'decrement']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn_menmas','disabled' => true,'x-bind:disabled' => '$wire.qty <= 1','wire:loading.attr' => 'disabled','wire:target' => 'decrement','wire:click' => 'decrement']); ?>
                -
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <span class="mx-2 text-gray-700 qtydad"><?php echo e($qty); ?></span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.secondary-button','data' => ['class' => 'btn_menmas','xBind:disabled' => '$wire.qty >= $wire.quantity','wire:loading.attr' => 'disabled','wire:target' => 'increment','wire:click' => 'increment']]); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn_menmas','x-bind:disabled' => '$wire.qty >= $wire.quantity','wire:loading.attr' => 'disabled','wire:target' => 'increment','wire:click' => 'increment']); ?>
                +
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <div class="flex-1">
            <div class="itemcolbtnweb">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['color' => 'orange','xBind:disabled' => '$wire.qty > $wire.quantity','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['color' => 'orange','x-bind:disabled' => '$wire.qty > $wire.quantity','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']); ?>
                    Agregar a la bolsa
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
            <div  class="itemcolorbtn">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['color' => 'orange','xBind:disabled' => '$wire.qty > $wire.quantity','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['color' => 'orange','x-bind:disabled' => '$wire.qty > $wire.quantity','class' => 'w-full','wire:click' => 'addItem','wire:loading.attr' => 'disabled','wire:target' => 'addItem']); ?>
                    Agregar
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
           
        </div>
    </div>
</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Dental Ecommerce\resources\views/livewire/add-cart-item.blade.php ENDPATH**/ ?>