<div class="container mt-14 py-8 ">

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table-responsive','data' => []]); ?>
<?php $component->withName('table-responsive'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <div class="px-6 pb-4  lg:py-4 text-center  md:mt-0 bg-white">
            <h1 class="text-2xl lg:text-4xl font-bold link_vrd ">Bolsa de compras</h1>
        </div>

        <?php if(Cart::count()): ?>
            <table class="min-w-full brdever_tble divide-y divide-green-900">
                <thead class="bg-gray-50 brdever_tble">
                    <tr>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-bold colorverderr uppercase tracking-wider">
                            Producto
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-bold colorverderr uppercase tracking-wider">
                            Precio
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-bold colorverderr uppercase tracking-wider">
                            Cantidad
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-bold colorverderr uppercase tracking-wider">
                            Subtotal
                        </th>

                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-green-900 brdever_tble">
                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr >
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10">
                                        <img class="h-10 w-10 rounded-full object-cover object-center"
                                            src="<?php echo e($item->options->image); ?>" alt="">
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm  colorbroywm font-bold">
                                            <?php echo e($item->name); ?>

                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php if($item->options->color): ?>
                                                <span class="capitalize">
                                                    - Color:<?php echo e(__($item->options->color)); ?>

                                                </span>
                                            <?php endif; ?>
                                            <?php if($item->options->size): ?>
                                                <span class="mx-1"> - </span>
                                                <span> <?php echo e($item->options->size); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                               
                                <div class="text-sm colorbroywm font-bold"><span>S/ <?php echo e($item->price); ?></span>
                                    <a class="ml-6 cursor-pointer hover:text-red-600" wire:click="delete('<?php echo e($item->rowId); ?>')" wire:loading.class="text-red-600 opacity-600" wire:target="delete('<?php echo e($item->rowId); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </a></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm colorbroywm font-bold">
                                    <?php if($item->options->size): ?>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-cart-size', ['rowId' => $item->rowId])->html();
} elseif ($_instance->childHasBeenRendered($item->rowId)) {
    $componentId = $_instance->getRenderedChildComponentId($item->rowId);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->rowId);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->rowId);
} else {
    $response = \Livewire\Livewire::mount('update-cart-size', ['rowId' => $item->rowId]);
    $html = $response->html();
    $_instance->logRenderedChild($item->rowId, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                <?php elseif($item->options->color): ?>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-cart-color', ['rowId' => $item->rowId])->html();
} elseif ($_instance->childHasBeenRendered($item->rowId)) {
    $componentId = $_instance->getRenderedChildComponentId($item->rowId);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->rowId);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->rowId);
} else {
    $response = \Livewire\Livewire::mount('update-cart-color', ['rowId' => $item->rowId]);
    $html = $response->html();
    $_instance->logRenderedChild($item->rowId, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                <?php else: ?>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-cart-item', ['rowId' => $item->rowId])->html();
} elseif ($_instance->childHasBeenRendered($item->rowId)) {
    $componentId = $_instance->getRenderedChildComponentId($item->rowId);
    $componentTag = $_instance->getRenderedChildComponentTagName($item->rowId);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item->rowId);
} else {
    $response = \Livewire\Livewire::mount('update-cart-item', ['rowId' => $item->rowId]);
    $html = $response->html();
    $_instance->logRenderedChild($item->rowId, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm colorbroywm font-bold">
                                <div class="text-sm  colorbroywm font-bold">
                                    S/ <?php echo e($item->price * $item->qty); ?>

                                </div>
                               
                            </td>

                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="px-6 py-4">
                <a class="text-sm cursor-pointer hover:underline mt-3 inline-block" wire:click="destroy">
                    <i class="fas fa-trash"></i>
                    Borrar carrito de compras
                </a>
            </div>
        <?php else: ?>
            <div class="flex flex-col items-center mt-2 md:mt-0 py-4">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cart','data' => []]); ?>
<?php $component->withName('cart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <p class="text-sm lg:text-lg text-gray-700 mt-4">TU BOLSA DE COMPRAS ESTÁ VACÍO</p>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button-enlace','data' => ['href' => '/','class' => 'mt-4 bg-yellow-600 px-16']]); ?>
<?php $component->withName('button-enlace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => '/','class' => 'mt-4 bg-yellow-600 px-16']); ?>
                    Ir al inicio
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>

        <?php endif; ?>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <!-- This example requires Tailwind CSS v2.0+ -->


    <?php if(Cart::count()): ?>

        <div class="bg-white rounded-lg shadow-lg px-6 py-4 mt-4">
            <div class="flex justify-between items-center">
                <div>
                    <p class="text-gray-700">
                        <span class="font-bold text-lg">Total:</span>
                        S/ <?php echo e(Cart::subTotal()); ?>

                    </p>
                </div>
                <div>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button-enlace','data' => ['href' => ''.e(route('orders.create')).'','class' => 'bg-orange-500']]); ?>
<?php $component->withName('button-enlace'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('orders.create')).'','class' => 'bg-orange-500']); ?>
                        Continuar
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </div>

        </div>

    <?php endif; ?>

</div>
<?php /**PATH C:\Users\RAMIREZ\Desktop\LARAVEL\Dental Ecommerce\resources\views/livewire/shopping-cart.blade.php ENDPATH**/ ?>